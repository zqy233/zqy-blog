# npm-check

> 检查npm依赖包是否有更新，并可以进行批量更新

## 全局安装

```sh
npm install -g npm-check
```

##  批量更新当前项目包版本

```sh
# 按空格选择
npm-check -u
# 更新全局包版本
npm-check -u -g
```

