# postmon

## tunneling [socket](https://gitee.com/link?target=https%3A%2F%2Fso.csdn.net%2Fso%2Fsearch%3Fq%3Dsocket%26spm%3D1001.2101.3001.7020) could not be established, cause=connect ECONNREFUSED 192.168.18.17:8080

访问能正常访问的接口，一直报错

postman左上角file->settings->proxy->去掉所有proxy选项

